//! Top-level arch re-export. Selects implementation at compile time.
//! Every other kernel module calls `crate::arch::*` — never the arch-specific path.

#[cfg(target_arch = "x86_64")]
pub use x86_64::{
    boot_stack_top, busy_delay, clear_screen, discover, enable_wx_paging, get_char, hw_entropy, init, kernel_end,
    kernel_sections, scan_pci, shutdown, zero_phys, probe_vbox, VirtualBoxProfile, AtaDriveInfo,
    init_vtd, get_iommu_status, init_input, poll_input_event, init_nic, nic_transmit, nic_receive, nic_mac, rdtsc,
};

#[cfg(target_arch = "aarch64")]
pub use aarch64::{
    boot_stack_top, busy_delay, clear_screen, discover, enable_wx_paging, get_char, hw_entropy, init, kernel_end,
    kernel_sections, scan_pci, shutdown, zero_phys, probe_vbox, VirtualBoxProfile, AtaDriveInfo,
    init_vtd, get_iommu_status, init_input, poll_input_event, init_nic, nic_transmit, nic_receive, nic_mac, rdtsc,
};

#[cfg(target_arch = "x86_64")]  pub mod x86_64;
#[cfg(target_arch = "aarch64")] pub mod aarch64;
